MAX PAYNE 3 SCRIPT HOOK v1.0.17.0
(C) Unknown Modder (twitter.com/unknownmodder)

REDISTRIBUTION OF THIS ARCHIVE IS NOT ALLOWED,
USE THE FOLLOWING LINK INSTEAD: https://unknownmodder.github.io/maxpayne3

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR
THE USE OR OTHER DEALINGS IN THE SOFTWARE

[Requirements]
Visual C++ Redistributable 2017 (x86)

[Supported versions]
- 1.0.0.114 (non-Steam)
- 1.0.0.216 (Steam)
- other versions should also work but they're untested

[Installation]
Copy ScriptHook.dll and dinput8.dll to the game's main folder (where MaxPayne3.exe is located)

[Run-time script reloading]
Create a file named "ScriptHook.dev" in the game's main folder
and press CTRL+R in-game. Now replace the script and press CTRL+R again.

[Donate]
Want to donate? Use this link: https://goo.gl/3WR6fF

I strongly think all mods should be free but
every donation would help a lot and is greatly appreciated.